package qq.app01.com.fragment_app.Tools.mode;

/**
 * Created by zhuxiaofeng on 2016/8/31.
 */
public class HomeMode {

    private String code;
    private String message;
    private ResultCodeMode resultCode;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ResultCodeMode getResultCode() {
        return resultCode;
    }

    public void setResultCode(ResultCodeMode resultCode) {
        this.resultCode = resultCode;
    }
}
