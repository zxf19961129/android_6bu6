package qq.app01.com.fragment_app.Tools.mode;

import java.util.List;

/**
 * Created by zhuxiaofeng on 2016/8/31.
 */
public class ResultCodeMode {

    private List<Ad> ad;
    private RecommenMode recommend;

    public List<Ad> getAd() {
        return ad;
    }

    public void setAd(List<Ad> ad) {
        this.ad = ad;
    }

    public RecommenMode getRecommenMode() {
        return recommend;
    }

    public void setRecommenMode(RecommenMode recommend) {
        this.recommend = recommend;
    }
}
