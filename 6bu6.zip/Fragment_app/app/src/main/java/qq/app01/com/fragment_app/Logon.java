package qq.app01.com.fragment_app;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import net.tsz.afinal.FinalBitmap;

import java.util.List;

import qq.app01.com.fragment_app.Tools.BU6_Tools;
import qq.app01.com.fragment_app.Tools.Httptools;
import qq.app01.com.fragment_app.Tools.mode3.Resultcode;
import qq.app01.com.fragment_app.Tools.mode4.DLmode;
import qq.app01.com.fragment_app.Tools.mode4.Result_mode;

public class Logon extends AppCompatActivity implements View.OnClickListener {

    ImageView imageView;
    TextView textView;
    Button denglu, wangjimima;
    EditText username, passworad;
    Httptools httptools = new Httptools();
    List<Result_mode> list;
    DLmode dLmode;

    public Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message tc) {
            super.handleMessage(tc);
            switch (tc.what) {
                case 200:
                    parseHandlerMsg(tc.obj);
                    break;
                default:
                    break;
            }
        }
    };

    private void parseHandlerMsg(Object obj) {
        if (obj != null && obj instanceof DLmode) {
            dLmode = (DLmode) obj;
            Toast.makeText(this, "登录" + dLmode.getMessage(), Toast.LENGTH_SHORT).show();
//            BlankFragment_four blankFragment_four = new BlankFragment_four();
//            FinalBitmap finalBitmap = FinalBitmap.create(this);
//            finalBitmap.display(blankFragment_four.imageView,dLmode.getResultCode().getImgUrl());
//            blankFragment_four.textView.setText(dLmode.getResultCode().getNickname());
            finish();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logon);

        imageView = (ImageView) findViewById(R.id.fanhui);
        imageView.setOnClickListener(this);

        textView = (TextView) findViewById(R.id.zhuce);
        textView.setOnClickListener(this);

        denglu = (Button) findViewById(R.id.butdenglu);
        denglu.setOnClickListener(this);

        wangjimima = (Button) findViewById(R.id.butwangji);
        wangjimima.setOnClickListener(this);

        username = (EditText) findViewById(R.id.user);
        passworad = (EditText) findViewById(R.id.pass);


    }

    public void denglu() {
        String user = username.getText().toString().trim();
        String pass = passworad.getText().toString().trim();
        httptools.denglu(mHandler, user, pass);

//        if("成功".equals(dLmode.getMessage())){

//            finish();
//        }else{
//            Toast.makeText(this,"账号或密码错误",Toast.LENGTH_SHORT).show();
//        }
//    }
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == imageView.getId()) {
            finish();
        } else if (id == textView.getId()) {
            Intent intent = new Intent(Logon.this, Register.class);
            startActivity(intent);
        } else if (id == denglu.getId()) {
            denglu();
        } else if (id == wangjimima.getId()) {
            Toast.makeText(this, "密码都忘记了，还登录个毛啊", Toast.LENGTH_SHORT).show();
        }
    }
}
