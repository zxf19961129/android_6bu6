package qq.app01.com.fragment_app.Tools.mode4;

import java.util.List;

/**
 * Created by zhuxiaofeng on 2016/9/7.
 */
public class DLmode {


    private String code;
    private String message;
    private Result_mode resultCode;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Result_mode getResultCode() {
        return resultCode;
    }

    public void setResultCode(Result_mode resultCode) {
        this.resultCode = resultCode;
    }
}
