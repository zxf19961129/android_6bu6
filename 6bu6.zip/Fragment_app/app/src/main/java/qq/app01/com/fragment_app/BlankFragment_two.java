package qq.app01.com.fragment_app;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import net.tsz.afinal.FinalBitmap;

import java.util.ArrayList;
import java.util.List;

import qq.app01.com.fragment_app.Tools.BU6_Tools;
import qq.app01.com.fragment_app.Tools.Httptools;
import qq.app01.com.fragment_app.Tools.mode.HengMode;
import qq.app01.com.fragment_app.Tools.mode.HomeMode;
import qq.app01.com.fragment_app.Tools.mode1.MessageMode;
import qq.app01.com.fragment_app.Tools.mode1.TCMode;


public class BlankFragment_two extends Fragment {

    Httptools httptools = Httptools.getHttptools();
    private TCMode tcMode;
    List<MessageMode> list;
    BaseAdapter baseAdapter;
    private ListView listView;

    public Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message tc) {
            super.handleMessage(tc);
            switch (tc.what) {
                case 100:
                    parseHandlerMsg(tc.obj);
                    break;
                default:
                    break;
            }
        }
    };

    private void parseHandlerMsg(Object obj) {
        if (obj != null && obj instanceof TCMode) {
            tcMode = (TCMode) obj;
            messa();
        }
    }

    public void messa() {
        list = new ArrayList();
        for (int i = 0; i < tcMode.getResultCode().size(); i++) {
            list.add(tcMode.getResultCode().get(i));
        }
        BlankFragment_one ba = new BlankFragment_one();
        ba.setPullLvHeight(listView);
        //需要把 baseAdapter提交一下
        baseAdapter.notifyDataSetChanged();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //创建该Fragment时调用该方法开始从网络获取数据
        httptools.getsendxinxi(mHandler,"1","5","1","1","1");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_blank_fragment_two, container, false);

        listView = (ListView) view.findViewById(R.id.list2);
        listView.setAdapter(base());
        return view;
    }


    public BaseAdapter base() {
        baseAdapter = new BaseAdapter() {
            @Override
            public int getCount() {

                return list == null ? 0 : list.size();
            }

            @Override
            public Object getItem(int position) {
                return null;
            }

            @Override
            public long getItemId(int position) {
                return position;
            }

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                LayoutInflater innn = LayoutInflater.from(getActivity());
                View view = innn.inflate(R.layout.tongcheng, null);
                ImageView imageView = (ImageView)view.findViewById(R.id.img);
                FinalBitmap finalBitmap = FinalBitmap.create(getActivity());
                finalBitmap.display(imageView, BU6_Tools.BASE + list.get(position).getPic());
                TextView textView  = (TextView)view.findViewById(R.id.textshuju01);
                textView.setText(list.get(position).getShopname());
                TextView textView2  = (TextView)view.findViewById(R.id.textshuju02);
                textView2.setText("接单数量："+list.get(position).getOrdernum()+"单");
                TextView textView3  = (TextView)view.findViewById(R.id.textshuju03);
                textView3.setText("地址："+list.get(position).getAddress());
                TextView textView4  = (TextView)view.findViewById(R.id.textshuju04);
                textView4.setText(list.get(position).getContent());
                TextView textView5  = (TextView)view.findViewById(R.id.textshuju05);
                textView5.setText(list.get(position).getJuli()+"km");
                return view;
            }
        };
        return baseAdapter;
    }

}
