package qq.app01.com.fragment_app.Tools.mode1;

import java.util.List;

/**
 * Created by zhuxiaofeng on 2016/9/2.
 */
public class TCMode {

    private String code;
    private String message;
    private List<MessageMode> resultCode;


    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<MessageMode> getResultCode() {
        return resultCode;
    }

    public void setResultCode(List<MessageMode> resultCode) {
        this.resultCode = resultCode;
    }
}
