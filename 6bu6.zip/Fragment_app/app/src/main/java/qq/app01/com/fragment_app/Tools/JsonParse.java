package qq.app01.com.fragment_app.Tools;

import com.google.gson.Gson;

import qq.app01.com.fragment_app.Tools.mode.HomeMode;
import qq.app01.com.fragment_app.Tools.mode1.TCMode;
import qq.app01.com.fragment_app.Tools.mode2.YHmode;
import qq.app01.com.fragment_app.Tools.mode3.Resultcode;
import qq.app01.com.fragment_app.Tools.mode4.DLmode;

/**
 * Created by zhuxiaofeng on 2016/8/31.
 */
public class JsonParse {


    public static HomeMode result(String message){
        HomeMode homeMode = null;
        Gson gson = new Gson();
        homeMode = gson.fromJson(message,HomeMode.class);
        return homeMode;
    }

    public static TCMode result2(String message){
        TCMode tcMode = null;
        Gson gson = new Gson();
        tcMode = gson.fromJson(message,TCMode.class);
        return tcMode;
    }

    public static YHmode result3(String message){
        YHmode yHmode = null;
        Gson gson = new Gson();
        yHmode = gson.fromJson(message,YHmode.class);
        return yHmode;
    }

    public static Resultcode result4(String message){
        Resultcode resultcode = null;
        Gson gson = new Gson();
        resultcode = gson.fromJson(message,Resultcode.class);
        return resultcode;
    }
    public static DLmode result5(String message){
        DLmode dLmode = null;
        Gson gson = new Gson();
        dLmode = gson.fromJson(message,DLmode.class);
        return dLmode;
    }

}
