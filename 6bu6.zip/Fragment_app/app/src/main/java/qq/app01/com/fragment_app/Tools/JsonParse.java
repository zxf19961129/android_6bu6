package qq.app01.com.fragment_app.Tools;

import com.google.gson.Gson;

import qq.app01.com.fragment_app.Tools.mode.HomeMode;
import qq.app01.com.fragment_app.Tools.mode1.TCMode;

/**
 * Created by zhuxiaofeng on 2016/8/31.
 */
public class JsonParse {


    public static HomeMode result(String message){
        HomeMode homeMode = null;
        Gson gson = new Gson();
        homeMode = gson.fromJson(message,HomeMode.class);
        return homeMode;
    }

    public static TCMode result2(String message){
        TCMode tcMode = null;
        Gson gson = new Gson();
        tcMode = gson.fromJson(message,TCMode.class);
        return tcMode;
    }

}
