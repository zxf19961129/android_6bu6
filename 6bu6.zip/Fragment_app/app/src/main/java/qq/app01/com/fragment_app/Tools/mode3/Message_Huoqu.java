package qq.app01.com.fragment_app.Tools.mode3;

/**
 * Created by zhuxiaofeng on 2016/9/6.
 */
public class Message_Huoqu {

    private String mobile;

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
}
