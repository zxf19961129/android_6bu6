package qq.app01.com.fragment_app.Tools.mode;

import java.util.List;

/**
 * Created by zhuxiaofeng on 2016/8/31.
 */
public class RecommenMode {


    private List<HengMode> heng;

    public List<HengMode> getHeng() {
        return heng;
    }

    public void setHeng(List<HengMode> heng) {
        this.heng = heng;
    }
}
