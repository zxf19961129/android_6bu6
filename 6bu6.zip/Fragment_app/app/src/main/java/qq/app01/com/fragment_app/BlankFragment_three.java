package qq.app01.com.fragment_app;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import net.tsz.afinal.FinalBitmap;

import java.util.ArrayList;
import java.util.List;

import qq.app01.com.fragment_app.Tools.BU6_Tools;
import qq.app01.com.fragment_app.Tools.Httptools;
import qq.app01.com.fragment_app.Tools.mode1.MessageMode;
import qq.app01.com.fragment_app.Tools.mode1.TCMode;
import qq.app01.com.fragment_app.Tools.mode2.Message_mode_yh;
import qq.app01.com.fragment_app.Tools.mode2.YHmode;


public class BlankFragment_three extends Fragment {
    Httptools httptools = Httptools.getHttptools();
    YHmode yHmode;
    List<Message_mode_yh> list;
    BaseAdapter baseAdapter;

    ListView listView;


    public Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message tc) {
            super.handleMessage(tc);
            switch (tc.what) {
                case 100:
                    parseHandlerMsg(tc.obj);
                    break;
                default:
                    break;
            }
        }
    };

    private void parseHandlerMsg(Object obj) {
        if (obj != null && obj instanceof YHmode) {
            yHmode = (YHmode) obj;
            messa();
        }
    }

    public void messa() {
        list = new ArrayList();
        for (int i = 0; i < yHmode.getResultCode().size(); i++) {
            list.add(yHmode.getResultCode().get(i));
        }
        BlankFragment_one ba = new BlankFragment_one();
        ba.setPullLvHeight(listView);
//        需要把 baseAdapter提交一下
        baseAdapter.notifyDataSetChanged();
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        httptools.getsan(mHandler,"1","5","1","1");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_blank_fragment_three, container, false);

        listView = (ListView)view.findViewById(R.id.listview);
        listView.setAdapter(base());

        return view;
    }



    public BaseAdapter base() {
        baseAdapter = new BaseAdapter() {
            @Override
            public int getCount() {

                return list == null ? 0 : list.size();
            }

            @Override
            public Object getItem(int position) {
                return null;
            }

            @Override
            public long getItemId(int position) {
                return position;
            }

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                LayoutInflater innn = LayoutInflater.from(getActivity());
                View view = innn.inflate(R.layout.youhuizhuanqu, null);
                ImageView imageView = (ImageView)view.findViewById(R.id.img);
                FinalBitmap finalBitmap = FinalBitmap.create(getActivity());
                finalBitmap.display(imageView, BU6_Tools.BASE + list.get(position).getPic());

                TextView textView = (TextView)view.findViewById(R.id.diyihang);
                textView.setText(list.get(position).getShopname());

                TextView textView1 = (TextView)view.findViewById(R.id.dierhang);
                textView1.setText(list.get(position).getHuodong());

                TextView textView2 = (TextView)view.findViewById(R.id.disanhang);
                textView2.setText(list.get(position).getContent());

                TextView textView3 = (TextView)view.findViewById(R.id.st);
                textView3.setText("地址:"+list.get(position).getAddress());

                TextView textView4 = (TextView)view.findViewById(R.id.adress);
                textView4.setText(list.get(position).getJuli()+"km");

                ImageView imageView1 = (ImageView)view.findViewById(R.id.img1);
                if(position==0||position==1||position==3){
                   imageView1.setImageResource(R.drawable.zhekou);
                }else if(position==2||position==4){
                    imageView1.setImageResource(R.drawable.manjian);
                }
                return view;
            }
        };
        return baseAdapter;
    }



}
