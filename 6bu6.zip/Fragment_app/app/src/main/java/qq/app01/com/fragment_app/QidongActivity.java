package qq.app01.com.fragment_app;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Window;

public class QidongActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.content_qidong);
        Handler handler=new Handler();
        handler.postDelayed(new Start(),3000);
    }

    private class  Start implements Runnable{

        @Override
        public void run() {
            Intent intent=new Intent();
            intent.setClass(QidongActivity.this,MainActivity.class);
            startActivity(intent);
            QidongActivity.this.finish();
        }
    }

}
