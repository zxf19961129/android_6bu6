package qq.app01.com.fragment_app.Tools.mode2;

import java.util.List;

/**
 * Created by zhuxiaofeng on 2016/9/6.
 */
public class YHmode {


    private String code;
    private String message;
    private List<Message_mode_yh> resultCode;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<Message_mode_yh> getResultCode() {
        return resultCode;
    }

    public void setResultCode(List<Message_mode_yh> resultCode) {
        this.resultCode = resultCode;
    }

    public static class ResultCodeBean {
    }



}
