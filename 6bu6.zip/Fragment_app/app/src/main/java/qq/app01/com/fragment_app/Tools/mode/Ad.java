package qq.app01.com.fragment_app.Tools.mode;

/**
 * Created by zhuxiaofeng on 2016/8/31.
 */
public class Ad {

    private String id;
    private String title;
    private String pic;
    private String link;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }
}
