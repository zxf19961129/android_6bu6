package qq.app01.com.fragment_app;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import qq.app01.com.fragment_app.Tools.Httptools;
import qq.app01.com.fragment_app.Tools.mode3.Resultcode;

public class Register extends AppCompatActivity implements View.OnClickListener {
    ImageView imageView;
    TextView textView;
    Button huoqu, zhuce;
    Httptools httptools = new Httptools();
    EditText editText, username, code, pass;
    Resultcode resultcode;

    public Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message tc) {
            super.handleMessage(tc);
            switch (tc.what) {
                case 100:
                    parseHandlerMsg(tc.obj);
                    break;
                case 200:
                    parseHandlerMsg(tc.obj);
                default:
                    break;
            }
        }
    };

    private void parseHandlerMsg(Object obj) {
        if (obj != null && obj instanceof Resultcode) {
            resultcode = (Resultcode) obj;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        imageView = (ImageView) findViewById(R.id.fanhui);
        imageView.setOnClickListener(this);

        username = (EditText) findViewById(R.id.shoujihao);
        pass = (EditText) findViewById(R.id.passworad);
        code = (EditText) findViewById(R.id.pass);


        editText = (EditText) findViewById(R.id.shoujihao);
        editText.setOnClickListener(this);

        textView = (TextView) findViewById(R.id.zhuce);
        textView.setOnClickListener(this);

        huoqu = (Button) findViewById(R.id.yanzhengma);
        huoqu.setOnClickListener(this);

        zhuce = (Button) findViewById(R.id.butdenglu);
        zhuce.setOnClickListener(this);

    }

    //获取验证码
    public void huoqu(String mobile) {
        httptools.huoqu(mHandler, mobile);
    }

    //注册
    public void zhuce(String username, String passwd, String code) {
        httptools.zhuce(mHandler, username, passwd, code);
        if(resultcode.getResultCode().length()==6){
            Intent intent = new Intent(Register.this,Register_susses.class);
            startActivity(intent);
        }else{
            Toast.makeText(this,"注册失败，请检查验证码是否正确",Toast.LENGTH_SHORT).show();
        }

    }

    //判断密码进行注册
    public void panduan(){
        String pa = pass.getText().toString().trim();
        String cd = code.getText().toString().trim();
        String user = username.getText().toString().trim();
        Log.e("------------", resultcode.getResultCode());
        if ("".equals(pa)) {
            Toast.makeText(this, "密码不能为空", Toast.LENGTH_SHORT).show();
        } else {
            zhuce(user, pa, cd);
        }
    }
    //判断手机号获取验证码
    public void panduan_phone(){
        String user = username.getText().toString().trim();
        if ("".equals(user)) {
            Toast.makeText(this, "请输入您的手机号码", Toast.LENGTH_SHORT).show();
        } else if (user.length() != 11) {
            Toast.makeText(this, "手机号码必须为11位", Toast.LENGTH_SHORT).show();
        } else {
            huoqu(user);
        }
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == imageView.getId()) {
            finish();
        } else if (id == textView.getId()) {
            finish();
        } else if (id == zhuce.getId()) {
           panduan();
        } else if (id == huoqu.getId()) {
          panduan_phone();
        }
    }
}
