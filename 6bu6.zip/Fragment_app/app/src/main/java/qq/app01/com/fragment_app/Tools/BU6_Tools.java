package qq.app01.com.fragment_app.Tools;

/**
 * Created by zhuxiaofeng on 2016/8/30.
 */
public class BU6_Tools {

    public static final String BASE = "http://tc.ceol8.com";

    //首页信息的Url
    public static final String HOME = BASE + "/service/index.php?model=home&action=home_new";

    //同城爱玩的Url
    public static final String AIWAN = BASE + "/service/index.php?model=city&action=indexcity";

    //优惠专区的Url
    public static final String YOUHUI = BASE + "/service/index.php?model=favorable&action=favorableshoplist";

    //获取验证码Url
    public static final String YANZHENG = BASE+"/service/index.php?model=user&action=verifycode";

    //注册接口Url
    public static final String ZHUCE = BASE+"/service/index.php?model=user&action=register";

    //登录接口Url
    public static final String DENGLU = BASE+"/service/index.php?model=user&action=login";

}
