package qq.app01.com.fragment_app.Tools;

/**
 * Created by zhuxiaofeng on 2016/8/30.
 */
public class BU6_Tools {

    public  static final String BASE = "http://tc.ceol8.com";

    //首页信息的Url
    public static final String HOME = BASE+"/service/index.php?model=home&action=home_new";


}
