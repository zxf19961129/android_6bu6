package qq.app01.com.fragment_app.Tools;

import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.google.gson.Gson;

import net.tsz.afinal.FinalHttp;
import net.tsz.afinal.http.AjaxCallBack;
import net.tsz.afinal.http.AjaxParams;

import java.util.ArrayList;

import qq.app01.com.fragment_app.Tools.mode.HomeMode;
import qq.app01.com.fragment_app.Tools.mode1.TCMode;
import qq.app01.com.fragment_app.Tools.mode2.YHmode;
import qq.app01.com.fragment_app.Tools.mode3.Resultcode;
import qq.app01.com.fragment_app.Tools.mode4.DLmode;

/**
 * Created by zhuxiaofeng on 2016/8/30.
 */
public class Httptools {

    private static Httptools httptools;
    private FinalHttp finalHttp;

    public Httptools() {
        if (finalHttp == null) {
            finalHttp = new FinalHttp();
        }
    }

    public static Httptools getHttptools() {
        if (httptools == null) {
            httptools = new Httptools();
        }
        return httptools;
    }


    /**
     * 获取首页信息
     */
    public void getshouyexinxi(final Handler handler, String lat, String lng, String searcename) {
        String url = BU6_Tools.HOME + "&lat=" + lat + "&lng=" + lng;
        finalHttp.get(url, new AjaxCallBack<String>() {
            @Override
            public void onStart() {
                super.onStart();
                Log.e("*************", "onStart");
            }

            @Override
            public void onSuccess(String o) {
                super.onSuccess(o);
                Log.e("]]]]]]]]]]]]", "" + o);

                //获取到数据
                HomeMode homeMode = JsonParse.result(o);
                Message msg = new Message();
                msg.what = 100;
                msg.obj = homeMode;
                handler.sendMessage(msg);
            }

            @Override
            public void onFailure(Throwable t, int errorNo, String strMsg) {
                super.onFailure(t, errorNo, strMsg);
                Log.e("*************", "onFailure");
            }
        });
    }


    public void getsendxinxi(final Handler handler, String pageNumber, String pageSize, String city, String lat, String lng) {
        String url = BU6_Tools.AIWAN + "&pageNumber=" + pageNumber + "&pageSize=" + pageSize + "&city=" + city + "&lat=" + lat + "&lng=" + lng;
        finalHttp.get(url, new AjaxCallBack<String>() {
            @Override
            public void onStart() {
                super.onStart();
            }

            @Override
            public void onSuccess(String s) {
                super.onSuccess(s);
                Log.e("---------------", "" + s);
                //获取数据
                TCMode tcMode = JsonParse.result2(s);
                //发送数据
                Message tc = new Message();
                tc.what = 100;
                tc.obj = tcMode;
                handler.sendMessage(tc);
            }

            @Override
            public void onFailure(Throwable t, int errorNo, String strMsg) {
                super.onFailure(t, errorNo, strMsg);
                Log.e("*************", "onFailure");
            }
        });
    }

    public void getsan(final Handler handler, String pageNumber, String pageSize, String lat, String lng) {
        String url = BU6_Tools.YOUHUI + "&pageNumber=" + pageNumber + "&pageSize=" + pageSize + "&lat=" + lat + "&lng=" + lng;
        finalHttp.get(url, new AjaxCallBack<String>() {
            @Override
            public void onStart() {
                super.onStart();
                Log.e("请求开始", "onStart");
            }

            @Override
            public void onSuccess(String o) {
                super.onSuccess(o);
                Log.e("请求数据", o);
                //获取数据
                YHmode yHmode = JsonParse.result3(o);
                //发送数据
                Message tc = new Message();
                tc.what = 100;
                tc.obj = yHmode;
                handler.sendMessage(tc);
            }

            @Override
            public void onFailure(Throwable t, int errorNo, String strMsg) {
                super.onFailure(t, errorNo, strMsg);
                Log.e("请求失败", "onFailure");
            }
        });
    }

    public void huoqu(final Handler handler, String mobile) {
        String url = BU6_Tools.YANZHENG + "&mobile=" + mobile;
        finalHttp.get(url, new AjaxCallBack<String>() {
            @Override
            public void onStart() {
                super.onStart();
            }

            @Override
            public void onSuccess(String s) {
                super.onSuccess(s);
                Log.e("请求", s);
                //获取数据
                Resultcode resultcode = JsonParse.result4(s);
                //发送数据
                Message tc = new Message();
                tc.what = 100;
                tc.obj = resultcode;
                handler.sendMessage(tc);
            }

            @Override
            public void onFailure(Throwable t, int errorNo, String strMsg) {
                super.onFailure(t, errorNo, strMsg);
            }
        });
    }

    //注册
    public void zhuce(final Handler handler, String username, String passwd, String code) {
        String url = BU6_Tools.ZHUCE;
        AjaxParams ajaxParams = new AjaxParams();
        ajaxParams.put("username", username);
        ajaxParams.put("passwd", passwd);
        ajaxParams.put("code", code);
        finalHttp.post(url, ajaxParams, new AjaxCallBack<String>() {
            @Override
            public void onSuccess(String s) {
                super.onSuccess(s);
                Log.e("注册信息", s);
                Resultcode resultcode = JsonParse.result4(s);
                //发送数据
                Message tc = new Message();
                tc.what = 200;
                tc.obj = resultcode;
                handler.sendMessage(tc);
            }
        });

    }

    //登录
    public void denglu(final Handler handler, String username, String passwd) {
        String url = BU6_Tools.DENGLU + "&username=" + username + "&passwd=" + passwd;
        finalHttp.post(url, new AjaxCallBack<String>() {
            @Override
            public void onStart() {
                super.onStart();
            }

            @Override
            public void onSuccess(String s) {
                super.onSuccess(s);
                Log.e("请求数据信息", s);
                DLmode dLmode = JsonParse.result5(s);
                //发送数据
                Message tc = new Message();
                tc.what = 200;
                tc.obj = dLmode;
                handler.sendMessage(tc);
            }

            @Override
            public void onFailure(Throwable t, int errorNo, String strMsg) {
                super.onFailure(t, errorNo, strMsg);
            }
        });


    }
}
